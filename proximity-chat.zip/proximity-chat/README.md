# proximity chat

A Pen created on CodePen.

Original URL: [https://codepen.io/proximitychat/pen/ZYbqjYx](https://codepen.io/proximitychat/pen/ZYbqjYx).

Nearby Chat is a location-based messaging app that lets you communicate with people in your immediate vicinity, just like proximity chat in video games.