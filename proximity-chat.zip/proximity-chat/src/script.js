// Connect to your Socket.IO server
const socket = io('http://your-server-address:3000');

// Send location updates to server
function sendLocationToServer(latitude, longitude) {
  socket.emit('locationUpdate', {
    lat: latitude,
    lng: longitude,
    userId: 'user123' // Would come from your auth system
  });
}

// Listen for messages from nearby users
socket.on('newMessage', (data) => {
  addMessage(data.user, data.message, false, data.distance);
});

// Listen for nearby user updates
socket.on('nearbyUsers', (users) => {
  updateUserList(users);
});